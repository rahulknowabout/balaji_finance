<div class="col-md-3 left_col">
                <div class="left_col scroll-view">

                    <div class="navbar nav_title" style="border: 0;">
                        <a href="#" class="site_title"><i class="fa fa-book"></i> <span>Balaji Finance</span></a>
                    </div>
                    <div class="clearfix"></div>


                    <!-- menu prile quick info -->
                    <div class="profile">
                        <div class="profile_pic">
                            <img src="images/img.jpg" alt="..." class="img-circle profile_img">
                        </div>
                        <div class="profile_info">
                            <span>Welcome</span>
                            <h2>Admin</h2>
                        </div>
                    </div>
                    <!-- /menu prile quick info -->

                    <br />

                    <!-- sidebar menu -->
                    <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">

                        <div class="menu_section">
                            <p>&nbsp;</p>
							<h3>General</h3>
                           <ul class="nav side-menu">
						    <!--
                                <li><a href="index.php"><i class="fa fa-home"></i> Home </a></li>
                                <li><a><i class="fa fa-desktop"></i> UI Elements <span class="fa fa-chevron-down"></span></a>
                                    <ul class="nav child_menu" style="display: none">
										<li><a href="index.php?f=content&t=artical_cat_list">Page Category</a></li>
										<li><a href="index.php?f=content&t=artical_list">Landing Pages</a></li>
										<li><a href="index.php?f=menu&t=menu">Finance</a></li>
										<li><a href="index.php?f=banner&t=banner">Banners</a></li>
										<li><a href="index.php?f=imagegallary&t=imagegallary">Images</a></li>
                                    </ul>
                                </li>
								-->
								
								 <li><a><i class="fa fa-user"></i> Finance <span class="fa fa-chevron-down"></span></a>
                                    <ul class="nav child_menu" style="display: none">
										<li><a href="index.php?f=menu&t=menu">Finance</a></li>
										
										
                                    </ul>
                                </li>
                                
                                <li><a><i class="fa fa-user"></i> User <span class="fa fa-chevron-down"></span></a>
                                    <ul class="nav child_menu" style="display: none">
										<li><a href="index.php?f=user&t=users">User Listing</a></li>
										<li><a href="index.php?f=user&t=useraddedit">Add New User</a></li>
										
                                    </ul>
                                </li>
                                
								
								<!-- <li><a  href ="index.php?f=newsletter&t=newsletter"><i class="fa fa-bug"></i> Send NewsLetter </a></li>
								<li><a href ="index.php?f=faq&t=faq"><i class="fa fa-edit"></i> Manage FAQ </a></li>
								<li><a href="index.php?f=events&t=events_list"><i class="fa fa-bar-chart-o"></i> Manage Event </a></li>
								-->
								
                            </ul>
                        </div>
                        

                    </div>
                    <!-- /sidebar menu -->

                    <!-- /menu footer buttons -->
                    <div class="sidebar-footer hidden-small">
                         <a  href= "#" data-toggle="tooltip" data-placement="top" title="Settings">
                            <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
							
                        </a> 
                        <a data-toggle="tooltip" data-placement="top">
                            &nbsp;
                        </a>
                        <a data-toggle="tooltip" data-placement="top">
                            &nbsp;
                        </a>
                        <a  href = "login.php?act=logout" data-toggle="tooltip" data-placement="top" title="Logout">
                            <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
                        </a>
                    </div>
                    <!-- /menu footer buttons -->
                </div>
            </div>